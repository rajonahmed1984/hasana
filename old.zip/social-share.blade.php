
<div class="social-share-btns-container">
    <div class="social-share-btns">
        <a class="share-btn share-btn-twitter" href="https://twitter.com/intent/tweet?text=http://hasanaa.com/" rel="nofollow" target="_blank">
            <i class="bi bi-twitter"></i>
            Tweet
        </a>
        <a class="share-btn share-btn-facebook" href="https://www.facebook.com/sharer/sharer.php?u=http://hasanaa.com/" rel="nofollow" target="_blank">
            <i class="bi bi-facebook"></i>
            Share
        </a>
        <a class="share-btn share-btn-linkedin" href="https://www.linkedin.com/cws/share?url=http://hasanaa.com/" rel="nofollow" target="_blank">
            <i class="bi bi-linkedin"></i>
            Share
        </a>
    </div>
</div>
