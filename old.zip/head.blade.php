<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="keywords" content="" />
        <meta name="description" content="আল-কুরআনের অর্থ " />  
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="/images/hasana-logo-g.png">
    
        <title>Hasana &#187; আল-কুরআনের অর্থ জানা এবং বোঝার প্রচেষ্টা।    </title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">
        <link rel="stylesheet" href="css/hasana.css">
        <link rel="stylesheet" href="css/screen.css">
        <link rel="stylesheet" href="../css/hasana.css">
        <link rel="stylesheet" href="../css/screen.css">
    </head>