
                    <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
                        <div class="offcanvas-header">
                            <h5 class="offcanvas-title" id="offcanvasNavbarLabel"><img src="/hasana/images/hasana-logo-g.png" alt="Logo" width="100" height="auto" class="d-inline-block align-text-top">  </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                        </div>
                        <div class="offcanvas-body">
                            <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                                <hr>
                                <li class="nav-item">
                                    <a class="nav-link active" aria-current="page" href="/hasana/index.php">
                                        আল কুরআন বাংলা অনুবাদ (সূরা ক্রমে)
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#">আল কুরআন বাংলা অনুবাদ (পারা ক্রমে)</a>
                                </li>
                                <li class="nav-item disabled">
                                    <a class="nav-link" href="#">নামাজের দোয়া </a>
                                </li>
                                <li class="nav-item disabled">
                                    <a class="nav-link" href="#">ওমরাহ হজ্জ গাইড </a>
                                </li>
                                <li class="nav-item disabled">
                                    <a class="nav-link" href="#">হজ্জ গাইড</a>
                                </li>
                                <hr>
                                <li class="nav-item">
                                    <a class="nav-link" href="../about-hasana.php">আমাদের সম্পর্কে </a>
                                </li>
                                <li class="nav-item disabled">
                                    <a class="nav-link" href="#">ডিসক্লেইমার</a>
                                </li>
                                <li class="nav-item disabled">
                                    <a class="nav-link" href="#">প্রাইভেসি পলিসি</a>
                                </li>
                                <li class="nav-item disabled">
                                    <span>Beta Version 1.0.0</span>
                                </li>
                            </ul>
                        </div>
                    </div> 
                



