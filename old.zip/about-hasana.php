<?php include 'header.blade.php';?>

        <section class="body-section">
            <div class="container">
                <div class="card mt-5">
                    <div class="card-body">
                        <div class="top-section mx-auto py-4">
                            <h6>|</h6>
                            <small>অনুবাদকঃ হাফেয মুনির উদ্দীন আহমদ</small>
                        </div>
                    </div>
                </div>
            </div>
        </section>

<?php include 'footer.blade.php';?>